public interface Crewmate {
    public abstract void completeTask();
}
