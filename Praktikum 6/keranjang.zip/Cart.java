/**
 * Jangan lupa tambahkan kata kunci yang dibutuhkan
 */ 
import java.util.List;
import java.util.ArrayList;

public class Cart {
    /**
     * Tambahkan atribut kelas disini
     */ 
    private Account user;
    private List<Item> cart;
    /**
     * Konstruktor
     * Inisialisasi atribut kelas
     */
    public Cart(Account account) {
        user = account;
        cart = new ArrayList<Item>();
    }
    
    /**
     * Implementasi
     * return account
     */
    public Account getAccount() {
        return user;
    }

    /**
     * Implementasi
     * return list item
     */
    public List<Item> getItems() {
        return cart;
    }   

    /**
     * Implementasi
     * menambahkan item ke dalam list item
     */
    public void addItem(Item item) {
        cart.add(item);
    }

    /**
     * Implementasi
     * menghapus semua item yang memiliki nama sesuai dengan parameter name
     * 
     * Apabila keranjang kosong, lempar exception "Tidak ada barang di dalam keranjang"
     * Apabila barang tidak ditemukan, lempar exception "Barang tidak ditemukan di dalam keranjang"
     */
    public void removeItem(String name) throws Exception{
        if(cart.isEmpty()) throw new Exception("Tidak ada barang di dalam keranjang");
        List<Item> newCart = new ArrayList<Item>();
        for(Item i : cart)
        {
            if(i.getName() != name) newCart.add(i); 
        }
        if(newCart.size() == cart.size()) throw new Exception("Barang tidak ditemukan di dalam keranjang");
        else cart = newCart;
    }

    /**
     * Implementasi
     * mengembalikan total harga semua barang di dalam keranjang
     */
    public int getTotalPrice() {
        int totalPrice = 0;
        for(Item i : cart) totalPrice += i.getTotalPrice();
        return totalPrice;
    }

    /**
     * Implementasi
     * mengurangi saldo sejumlah total harga semua barang
     * mengosongkan keranjang
     * 
     * Apabila keranjang kosong, lempar exception "Keranjang kosong"
     * Apabila saldo tidak mencukupi, lempar exception "Saldo tidak mencukupi untuk melakukan pembayaran"
     */
    public void checkout() throws Exception {
        if(cart.isEmpty()) throw new Exception("Keranjang kosong");
        if(user.getSaldo() < this.getTotalPrice()) throw new Exception("Saldo tidak mencukupi untuk melakukan pembayaran");
        user.reduceSaldo(this.getTotalPrice());
        cart.clear();
    }
}